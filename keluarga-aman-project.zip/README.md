# Keluarga Aman — Android prototype

This repository builds two Android debug APKs:
- Parent: `assembleParentDebug`
- Child: `assembleChildDebug`

## Build in GitHub Actions
Push this project to the `main` branch, then open **Actions** and run
**Build Keluarga Aman APK**. Download the `Keluarga-Aman-APKs` artifact.

## Current scope
This is a starter prototype only. It does not yet implement account pairing,
cloud sync, location sharing, app-usage reports, or video/audio calling.
Camera and microphone are not accessed in this prototype. Any future
camera/microphone feature must be an explicit, visible session controlled
through Android's permission and foreground-service rules.
