package com.keluarga.aman

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val isParent = BuildConfig.FLAVOR == "parent"
        val bg = Color.rgb(19, 18, 31)
        val accent = Color.rgb(160, 120, 255)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(bg)
        }

        fun addText(value: String, size: Float, color: Int) {
            layout.addView(TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                setPadding(8, 14, 8, 14)
            })
        }

        addText("KELUARGA AMAN", 27f, Color.WHITE)
        addText(
            if (isParent) "APLIKASI ORANG TUA" else "APLIKASI ANAK",
            19f, accent
        )
        addText("Prototype 1.0", 14f, Color.LTGRAY)
        addText(
            if (isParent)
                "Dashboard orang tua akan dikembangkan di tahap berikutnya."
            else
                "Perangkat anak akan dipasangkan secara transparan dengan akun orang tua.",
            16f, Color.WHITE
        )
        addText(
            "Kamera dan mikrofon tidak aktif pada versi prototype ini.",
            13f, Color.LTGRAY
        )

        setContentView(layout)
    }
}
